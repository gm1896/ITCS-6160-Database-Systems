-- MySQL dump 10.13  Distrib 5.7.23, for Win64 (x86_64)
--
-- Host: fall2018dbatlani.cpca6yvg9gox.us-east-2.rds.amazonaws.com    Database: Electricity_Billing_System_incr_1
-- ------------------------------------------------------
-- Server version	5.7.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Tariff_Details`
--

DROP TABLE IF EXISTS `Tariff_Details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tariff_Details` (
  `zip_code` varchar(5) NOT NULL,
  `provider_name` varchar(30) NOT NULL,
  `peak_time_charge` double NOT NULL,
  `off_peak_time_charge` double NOT NULL,
  `peak_time` varchar(30) NOT NULL DEFAULT '0',
  `off_peak_time` varchar(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`zip_code`,`provider_name`),
  KEY `provider_name` (`provider_name`),
  CONSTRAINT `fk_Tariff_Details_1` FOREIGN KEY (`provider_name`) REFERENCES `Service_Provider` (`provider_name`),
  CONSTRAINT `fk_Tariff_Details_2` FOREIGN KEY (`zip_code`) REFERENCES `Zipcode_Details` (`zip_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tariff_Details`
--

LOCK TABLES `Tariff_Details` WRITE;
/*!40000 ALTER TABLE `Tariff_Details` DISABLE KEYS */;
INSERT INTO `Tariff_Details` VALUES ('31285','ENGIE',1.59,1,'8:00 AM-8:00 PM','8:01 PM- 7.59 AM'),('34912','NextEra Energy',1.86,0.9,'10:00 AM-10:PM','10:01 PM-9:59 AM'),('35132','Duke Energy',1.5,1,'10:00 AM-10:PM','10:00 AM-10:PM'),('91106','ENGIE',2.06,1.18,'8:00 AM-8:00 PM','8:01 PM- 7.59 AM'),('97788','Duke Energy',1.34,0.96,'10:00 AM-10:PM','10:00 AM-10:PM'),('97788','NextEra Energy',1.86,0.9,'10:00 AM-10:PM','10:01 PM-9:59 AM');
/*!40000 ALTER TABLE `Tariff_Details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-11 22:07:20
