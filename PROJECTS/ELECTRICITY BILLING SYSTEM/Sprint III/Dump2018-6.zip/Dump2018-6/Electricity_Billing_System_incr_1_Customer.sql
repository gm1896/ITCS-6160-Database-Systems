-- MySQL dump 10.13  Distrib 5.7.23, for Win64 (x86_64)
--
-- Host: fall2018dbatlani.cpca6yvg9gox.us-east-2.rds.amazonaws.com    Database: Electricity_Billing_System_incr_1
-- ------------------------------------------------------
-- Server version	5.7.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customer` (
  `customer_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `login_email_id` varchar(255) NOT NULL,
  `login_password` varchar(255) NOT NULL,
  `ssn` varchar(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) DEFAULT NULL,
  `zip_code` varchar(5) NOT NULL,
  `phone_no_primary` varchar(13) NOT NULL,
  `phone_no_secondary` varchar(13) DEFAULT NULL,
  `service_provider_name` varchar(50) NOT NULL,
  `register_date` date NOT NULL,
  `meter_type` enum('Electric','Solar') NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `ssn_UNIQUE` (`ssn`),
  UNIQUE KEY `login_email_id_UNIQUE` (`login_email_id`),
  KEY `zip_code` (`zip_code`),
  KEY `service_provider_name_idx` (`service_provider_name`),
  CONSTRAINT `fk_service_provider_name` FOREIGN KEY (`service_provider_name`) REFERENCES `Service_Provider` (`provider_name`),
  CONSTRAINT `fk_zipcode_1` FOREIGN KEY (`zip_code`) REFERENCES `Zipcode_Details` (`zip_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
INSERT INTO `Customer` VALUES (1,'sed.pede.nec@maurisanunc.co.uk','zsjdk@65','531349579','Lars','Keith','P.O. Box 795, 3438 Consectetuer Street','Ap #810-587 Odio. St.','31285','971-821-2399','1-822-395-977','ENGIE','2018-05-23','Electric'),(2,'Cras.lorem@gmail.com','abcd','769957804','Chadwick','Gallegos','3025 Quam. Road','7490 Leo Rd.','91106','478-274-7169','1-823-606-877','ENGIE','2008-10-09','Solar'),(3,'fermen0tum@gmail.com','zsjdk@65','792228819','Richard','Hahn','Ap #124-6114 Nonummy St.','P.O. Box 747, 7713 Proin St.','34912','253-588-3159','1-242-239-974','NextEra Energy','2005-03-27','Electric'),(4,'Vivamus@gmail.com','zsjdk@65','585314115','Madonna','Reynolds','4060 Dapibus Avenue','882-1519 Ipsum Avenue','35132','793-103-0076','1-620-331-907','Duke Energy','2016-09-08','Electric'),(5,'mauris@yahoo.com','zsjdk@65','445237639','Hiroko','Potts','Ap #413-2220 Sem, Ave','Ap #162-7256 A, Ave','97788','139-210-3455','1-405-770-116','Duke Energy','2006-07-16','Electric'),(6,'hdjkasd@gmail.com','jfshjb','458457896','kavya','poland','201 tri street',NULL,'97788','234-234-1323',NULL,'NextEra Energy','2010-10-10','Solar');
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-11 22:07:19
