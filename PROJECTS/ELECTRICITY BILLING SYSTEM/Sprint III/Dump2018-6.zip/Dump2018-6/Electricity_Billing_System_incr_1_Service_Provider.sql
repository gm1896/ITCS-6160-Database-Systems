-- MySQL dump 10.13  Distrib 5.7.23, for Win64 (x86_64)
--
-- Host: fall2018dbatlani.cpca6yvg9gox.us-east-2.rds.amazonaws.com    Database: Electricity_Billing_System_incr_1
-- ------------------------------------------------------
-- Server version	5.7.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Service_Provider`
--

DROP TABLE IF EXISTS `Service_Provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Service_Provider` (
  `provider_name` varchar(30) NOT NULL,
  `license_number` varchar(20) NOT NULL,
  `office_address_line_1` varchar(50) NOT NULL,
  `office_address_Line_2` varchar(50) DEFAULT NULL,
  `zip_code` varchar(5) NOT NULL,
  `head_office_number` varchar(13) NOT NULL,
  `helpline_number` varchar(13) NOT NULL,
  PRIMARY KEY (`provider_name`),
  UNIQUE KEY `license_number_UNIQUE` (`license_number`),
  KEY `zip_code_idx` (`zip_code`),
  CONSTRAINT `fk_zip_code` FOREIGN KEY (`zip_code`) REFERENCES `Zipcode_Details` (`zip_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Service_Provider`
--

LOCK TABLES `Service_Provider` WRITE;
/*!40000 ALTER TABLE `Service_Provider` DISABLE KEYS */;
INSERT INTO `Service_Provider` VALUES ('Duke Energy','12345678','201 Tryon Street',NULL,'35132','(526)548-4569','(526)896-1236'),('Engie','54513257','78 street',NULL,'34912','(524)245-8968','(524)478-2145'),('NextEra Energy','78945612','601 Travis Street','','31285','(305)246-1300','(321)457-9634');
/*!40000 ALTER TABLE `Service_Provider` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-11 22:07:23
