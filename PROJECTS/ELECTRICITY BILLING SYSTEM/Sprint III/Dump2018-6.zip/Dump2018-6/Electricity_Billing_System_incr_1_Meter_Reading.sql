-- MySQL dump 10.13  Distrib 5.7.23, for Win64 (x86_64)
--
-- Host: fall2018dbatlani.cpca6yvg9gox.us-east-2.rds.amazonaws.com    Database: Electricity_Billing_System_incr_1
-- ------------------------------------------------------
-- Server version	5.7.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Meter_Reading`
--

DROP TABLE IF EXISTS `Meter_Reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Meter_Reading` (
  `meter_number` int(10) NOT NULL,
  `peak_hour_reading` double DEFAULT '0',
  `off_peak_hour_reading` double NOT NULL DEFAULT '0',
  `meter_reading_date` date NOT NULL,
  `total_current_reading` double DEFAULT '0',
  `total_previous_reading` double DEFAULT '0',
  `customer_id` bigint(20) DEFAULT NULL,
  `meter_reading_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`meter_reading_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `fk_customer_id_2` FOREIGN KEY (`customer_id`) REFERENCES `Customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Meter_Reading`
--

LOCK TABLES `Meter_Reading` WRITE;
/*!40000 ALTER TABLE `Meter_Reading` DISABLE KEYS */;
INSERT INTO `Meter_Reading` VALUES (1001,120,60,'2018-07-18',280,100,1,1),(1001,100,50,'2018-09-18',630,480,1,2),(1001,106,41,'2018-10-18',777,630,1,3),(1002,86,54,'2018-09-25',347,200,2,4),(1003,109,59,'2018-09-26',668,500,3,5),(1004,112,86,'2018-08-23',798,600,4,6),(1004,96,80,'2018-09-23',565,389,4,7),(1004,44,86,'2018-10-23',695,565,4,8),(1005,98,61,'2018-09-20',389,230,5,9);
/*!40000 ALTER TABLE `Meter_Reading` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-11 22:07:21
